﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using JRPC_Client;
using XDevkit;

namespace MSPSpoofer
{
	// Token: 0x02000002 RID: 2
	public partial class Form1 : Form
	{
		// Token: 0x06000002 RID: 2 RVA: 0x0000206E File Offset: 0x0000026E
		public Form1()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000003 RID: 3 RVA: 0x00002086 File Offset: 0x00000286
		private void button3_Click(object sender, EventArgs e)
		{
			Process.Start("https://www.silentlive.online");
		}

        private IXboxConsole silent;

		// Token: 0x06000004 RID: 4 RVA: 0x000020FC File Offset: 0x000002FC
		private void button2_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Wait about a second after you press Purchase then press OK on this message box!");
			this.silent.SetMemory(2171119192u, new byte[]
			{
				56,
				128,
				0,
				5,
				128,
				99,
				0,
				28,
				144,
				131,
				0,
				4,
				56,
				128,
				5,
				57,
				144,
				131,
				0,
				8,
				56,
				96,
				0,
				0,
				78,
				128,
				0,
				32
			});
			this.silent.WriteInt32(2173603668u, 1610612736);
			this.silent.WriteInt32(2173604492u, 1207959752);
			this.silent.WriteInt32(2173622996u, 962592768);
			this.silent.WriteInt32(2417344776u, 1610612736);
			this.silent.XNotify("MSP Spoofed!");
		}

		// Token: 0x06000005 RID: 5 RVA: 0x00002094 File Offset: 0x00000294
		private void button4_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Instructions:\n");
		}

		// Token: 0x06000006 RID: 6 RVA: 0x000020A2 File Offset: 0x000002A2
		private void Form1_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000021A4 File Offset: 0x000003A4
		private void button1_Click(object sender, EventArgs e)
		{
			bool flag = !this.connected;
			if (flag)
			{
				try
				{
					bool flag2 = this.silent.Connect(out this.silent, "default");
					if (flag2)
					{
						MessageBox.Show("MSP Spoofer Connected!");
						this.silent.XNotify("MSP Spoofer Connected!\nCreated By Silent");
						this.connected = true;
						this.button1.Enabled = false;
						this.button1.Text = "Connected!";
					}
				}
				catch
				{
					MessageBox.Show("Failed to connect to silent, make sure neighborhood is connected and you have JRPC2 on your silent!");
				}
			}
		}
        

		// Token: 0x04000002 RID: 2
		public bool connected;

		// Token: 0x04000003 RID: 3
		public bool spoofed;
	}
}
