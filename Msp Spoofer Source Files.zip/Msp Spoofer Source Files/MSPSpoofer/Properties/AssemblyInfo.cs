﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: CompilationRelaxations(8)]
[assembly: Guid("9c41e34d-7225-4ad2-bd32-041e4906d426")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTitle("MSPSpoofer")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("MSPSpoofer")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
